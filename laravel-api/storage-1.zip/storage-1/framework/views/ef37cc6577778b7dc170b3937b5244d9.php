<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription en attente dans <?php echo e($mailData['ecole']); ?></title>
</head>
<body>
    Bonjour Parent.Nous avons reçu une demande d'inscription pour votre enfant <?php echo e($mailData['eleve']); ?> dans l'école <?php echo e($mailData['ecole']); ?>.
    La demande a été traitée et est <?php echo e($mailData['etat']); ?>.
    <?php if($mailData['motif']): ?>
    <p>Motif : <?php echo e($mailData['motif']); ?></p>
    <?php endif; ?>
    <?php if(count($mailData["champs"]) != 0): ?>
    <p>Vous devez modifier : </p>
    <ul>
        <?php $__currentLoopData = $mailData["champs1"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $champ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li> <?php echo e($champ ?? ""); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</body>
</html><?php /**PATH /home/fadelsew02/Desktop/manage-school/laravel-api/resources/views/mail/notification_mail_attente.blade.php ENDPATH**/ ?>