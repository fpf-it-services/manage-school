<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription en attente dans <?php echo e($mailData['ecole']); ?></title>
</head>
<body>
    Bonjour Parent.Nous avons reçu une demande d'inscription pour votre enfant <?php echo e($mailData['eleve']); ?> dans l'école <?php echo e($mailData['ecole']); ?>.
    <?php if($mailData['nouveau']): ?>
    Pour suivre cette demande,un compte vous a été crée et les informations de connexion sont:
        <p>Email : <?php echo e($mailData['email']); ?></p>
        <p>Mot de passe : <?php echo e($mailData['password']); ?></p>
    <?php else: ?>       
    Vos informations de connexion restent les mêmes. 
    <?php endif; ?>
</body>
</html><?php /**PATH /home/fadelsew02/Desktop/manage-school/laravel-api/resources/views/mail/inscription_attente_eleve.blade.php ENDPATH**/ ?>