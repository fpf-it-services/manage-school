<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription en attente d'une école</title>
</head>
<body>
    Bonjour Admin. J'ai fait une inscription pour une école.Voici mes informations :
        <p>Nom : <?php echo e($mailData['nom']); ?></p>
        <p>Email : <?php echo e($mailData['email']); ?></p>
        <p>Adresse : <?php echo e($mailData['adresse']); ?></p>
        <p>Téléphone : <?php echo e($mailData['telephone']); ?></p>
</body>
</html><?php /**PATH /home/fadelsew02/Desktop/manage-school/laravel-api/resources/views/mail/inscription_attente.blade.php ENDPATH**/ ?>